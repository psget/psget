function Get-ManifestTestModuleName {
    return 'ManifestTestModule'
}