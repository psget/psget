$here = (Split-Path -parent $MyInvocation.MyCommand.Definition)
New-Item -ItemType File -Path $here\installed.txt | Out-Null