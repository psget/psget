$here = (Split-Path -parent $MyInvocation.MyCommand.Definition)
New-Item -ItemType File -Path $here\updated.txt | Out-Null